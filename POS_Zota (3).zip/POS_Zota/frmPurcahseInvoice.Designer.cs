﻿
namespace POS_Zota
{
    partial class frmPurcahseInvoice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPurcahseInvoice));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnBack = new System.Windows.Forms.Button();
            this.pnlBottom = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.pnlCalculation = new System.Windows.Forms.Panel();
            this.pnlRight = new System.Windows.Forms.Panel();
            this.txtGrossAmount = new System.Windows.Forms.TextBox();
            this.lblGrossAmt = new System.Windows.Forms.Label();
            this.txtDiscountAmtPercentage = new System.Windows.Forms.TextBox();
            this.lblDiscountAmtPer = new System.Windows.Forms.Label();
            this.txtDiscountAmt = new System.Windows.Forms.TextBox();
            this.txtRoundOff = new System.Windows.Forms.TextBox();
            this.lblRoundOff = new System.Windows.Forms.Label();
            this.lblNetAmount = new System.Windows.Forms.Label();
            this.txtNetAmount = new System.Windows.Forms.TextBox();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlMiddle = new System.Windows.Forms.Panel();
            this.pnlPurchaseInvoiceDetail = new System.Windows.Forms.Panel();
            this.dgvPurchaseInvoiceDetail = new System.Windows.Forms.DataGridView();
            this.Product_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Mfg_Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Exp_Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Purchase_Rate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MRP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Free_Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Available_Stk_Qty = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Discount_Perc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Discount_Amt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Sub_Total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Net_Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblPurchaseInvoiceDetail = new System.Windows.Forms.Label();
            this.pnlSearchProduct = new System.Windows.Forms.Panel();
            this.dgvVendorDetail = new System.Windows.Forms.DataGridView();
            this.Vendor_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Vendor_Name = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Vendor_Address = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Vendor_Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtPurchaseRate = new System.Windows.Forms.TextBox();
            this.lblPurchaseRate = new System.Windows.Forms.Label();
            this.txtDiscAmt = new System.Windows.Forms.TextBox();
            this.lblDiscAmt = new System.Windows.Forms.Label();
            this.txtDisPer = new System.Windows.Forms.TextBox();
            this.lblDiscountPer = new System.Windows.Forms.Label();
            this.txtFreeQty = new System.Windows.Forms.TextBox();
            this.lblFreeQty = new System.Windows.Forms.Label();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.lblQty = new System.Windows.Forms.Label();
            this.groupBoxAvlQty = new System.Windows.Forms.GroupBox();
            this.lblAvlQty = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnProductAdd = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lblMRP = new System.Windows.Forms.Label();
            this.dateExp = new System.Windows.Forms.DateTimePicker();
            this.lblExpDate = new System.Windows.Forms.Label();
            this.dateMfg = new System.Windows.Forms.DateTimePicker();
            this.lblMfgDate = new System.Windows.Forms.Label();
            this.txtProductCode = new System.Windows.Forms.TextBox();
            this.lblProductCode = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblProductName = new System.Windows.Forms.Label();
            this.rdbProductCode = new System.Windows.Forms.RadioButton();
            this.rdbProductName = new System.Windows.Forms.RadioButton();
            this.lblFilterType = new System.Windows.Forms.Label();
            this.pnlSearchProductTitle = new System.Windows.Forms.Panel();
            this.lblSearchProduct = new System.Windows.Forms.Label();
            this.pnlHeader = new System.Windows.Forms.Panel();
            this.comboVendorType = new System.Windows.Forms.ComboBox();
            this.lblVendorType = new System.Windows.Forms.Label();
            this.txtVendorAddress = new System.Windows.Forms.TextBox();
            this.txtVendorName = new System.Windows.Forms.TextBox();
            this.txtVendorCode = new System.Windows.Forms.TextBox();
            this.lblVendorAddress = new System.Windows.Forms.Label();
            this.lblVendorName = new System.Windows.Forms.Label();
            this.lblVendorCode = new System.Windows.Forms.Label();
            this.dueDatePurchaseInvoice = new System.Windows.Forms.DateTimePicker();
            this.datePurchaseInvoice = new System.Windows.Forms.DateTimePicker();
            this.lblPurchaseInvoiceDueDate = new System.Windows.Forms.Label();
            this.lblPurchaseInvoiceDate = new System.Windows.Forms.Label();
            this.txtPurchaseInvoiceNo = new System.Windows.Forms.TextBox();
            this.lblPurchaseInvoiceNo = new System.Windows.Forms.Label();
            this.pnlPurchaseInvoiceHeader = new System.Windows.Forms.Panel();
            this.lblPurchaseInvoice = new System.Windows.Forms.Label();
            this.pnlBottom.SuspendLayout();
            this.panel3.SuspendLayout();
            this.pnlCalculation.SuspendLayout();
            this.pnlRight.SuspendLayout();
            this.pnlMain.SuspendLayout();
            this.pnlMiddle.SuspendLayout();
            this.pnlPurchaseInvoiceDetail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPurchaseInvoiceDetail)).BeginInit();
            this.panel2.SuspendLayout();
            this.pnlSearchProduct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVendorDetail)).BeginInit();
            this.groupBoxAvlQty.SuspendLayout();
            this.pnlSearchProductTitle.SuspendLayout();
            this.pnlHeader.SuspendLayout();
            this.pnlPurchaseInvoiceHeader.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.White;
            this.btnBack.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Image = ((System.Drawing.Image)(resources.GetObject("btnBack.Image")));
            this.btnBack.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBack.Location = new System.Drawing.Point(603, 14);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 29);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "Back";
            this.btnBack.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // pnlBottom
            // 
            this.pnlBottom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlBottom.Controls.Add(this.panel3);
            this.pnlBottom.Controls.Add(this.pnlCalculation);
            this.pnlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlBottom.Location = new System.Drawing.Point(0, 463);
            this.pnlBottom.Name = "pnlBottom";
            this.pnlBottom.Size = new System.Drawing.Size(1343, 233);
            this.pnlBottom.TabIndex = 2;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.btnBack);
            this.panel3.Controls.Add(this.btnClear);
            this.panel3.Controls.Add(this.btnSave);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 176);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1341, 55);
            this.panel3.TabIndex = 1;
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.White;
            this.btnClear.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Image = ((System.Drawing.Image)(resources.GetObject("btnClear.Image")));
            this.btnClear.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClear.Location = new System.Drawing.Point(522, 14);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 29);
            this.btnClear.TabIndex = 1;
            this.btnClear.Text = "Clear";
            this.btnClear.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClear.UseVisualStyleBackColor = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.White;
            this.btnSave.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(441, 14);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 29);
            this.btnSave.TabIndex = 0;
            this.btnSave.Text = "Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.UseVisualStyleBackColor = false;
            // 
            // pnlCalculation
            // 
            this.pnlCalculation.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCalculation.Controls.Add(this.pnlRight);
            this.pnlCalculation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlCalculation.Location = new System.Drawing.Point(0, 0);
            this.pnlCalculation.Name = "pnlCalculation";
            this.pnlCalculation.Size = new System.Drawing.Size(1341, 231);
            this.pnlCalculation.TabIndex = 0;
            // 
            // pnlRight
            // 
            this.pnlRight.Controls.Add(this.txtGrossAmount);
            this.pnlRight.Controls.Add(this.lblGrossAmt);
            this.pnlRight.Controls.Add(this.txtDiscountAmtPercentage);
            this.pnlRight.Controls.Add(this.lblDiscountAmtPer);
            this.pnlRight.Controls.Add(this.txtDiscountAmt);
            this.pnlRight.Controls.Add(this.txtRoundOff);
            this.pnlRight.Controls.Add(this.lblRoundOff);
            this.pnlRight.Controls.Add(this.lblNetAmount);
            this.pnlRight.Controls.Add(this.txtNetAmount);
            this.pnlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlRight.Location = new System.Drawing.Point(906, 0);
            this.pnlRight.Name = "pnlRight";
            this.pnlRight.Size = new System.Drawing.Size(433, 229);
            this.pnlRight.TabIndex = 10;
            // 
            // txtGrossAmount
            // 
            this.txtGrossAmount.Location = new System.Drawing.Point(236, 22);
            this.txtGrossAmount.Name = "txtGrossAmount";
            this.txtGrossAmount.Size = new System.Drawing.Size(176, 26);
            this.txtGrossAmount.TabIndex = 19;
            // 
            // lblGrossAmt
            // 
            this.lblGrossAmt.AutoSize = true;
            this.lblGrossAmt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGrossAmt.Location = new System.Drawing.Point(113, 29);
            this.lblGrossAmt.Name = "lblGrossAmt";
            this.lblGrossAmt.Size = new System.Drawing.Size(117, 19);
            this.lblGrossAmt.TabIndex = 18;
            this.lblGrossAmt.Text = "Gross Amount  :";
            // 
            // txtDiscountAmtPercentage
            // 
            this.txtDiscountAmtPercentage.Location = new System.Drawing.Point(236, 57);
            this.txtDiscountAmtPercentage.Name = "txtDiscountAmtPercentage";
            this.txtDiscountAmtPercentage.Size = new System.Drawing.Size(72, 26);
            this.txtDiscountAmtPercentage.TabIndex = 17;
            // 
            // lblDiscountAmtPer
            // 
            this.lblDiscountAmtPer.AutoSize = true;
            this.lblDiscountAmtPer.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiscountAmtPer.Location = new System.Drawing.Point(68, 64);
            this.lblDiscountAmtPer.Name = "lblDiscountAmtPer";
            this.lblDiscountAmtPer.Size = new System.Drawing.Size(162, 19);
            this.lblDiscountAmtPer.TabIndex = 16;
            this.lblDiscountAmtPer.Text = "Discount Amount (%) :";
            // 
            // txtDiscountAmt
            // 
            this.txtDiscountAmt.Location = new System.Drawing.Point(314, 57);
            this.txtDiscountAmt.Name = "txtDiscountAmt";
            this.txtDiscountAmt.Size = new System.Drawing.Size(98, 26);
            this.txtDiscountAmt.TabIndex = 15;
            // 
            // txtRoundOff
            // 
            this.txtRoundOff.Location = new System.Drawing.Point(236, 89);
            this.txtRoundOff.Name = "txtRoundOff";
            this.txtRoundOff.Size = new System.Drawing.Size(176, 26);
            this.txtRoundOff.TabIndex = 13;
            // 
            // lblRoundOff
            // 
            this.lblRoundOff.AutoSize = true;
            this.lblRoundOff.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRoundOff.Location = new System.Drawing.Point(106, 96);
            this.lblRoundOff.Name = "lblRoundOff";
            this.lblRoundOff.Size = new System.Drawing.Size(124, 19);
            this.lblRoundOff.TabIndex = 12;
            this.lblRoundOff.Text = "Round Off (+/-)  :";
            // 
            // lblNetAmount
            // 
            this.lblNetAmount.AutoSize = true;
            this.lblNetAmount.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNetAmount.Location = new System.Drawing.Point(135, 128);
            this.lblNetAmount.Name = "lblNetAmount";
            this.lblNetAmount.Size = new System.Drawing.Size(95, 19);
            this.lblNetAmount.TabIndex = 11;
            this.lblNetAmount.Text = "NetAmount :";
            // 
            // txtNetAmount
            // 
            this.txtNetAmount.Location = new System.Drawing.Point(236, 121);
            this.txtNetAmount.Name = "txtNetAmount";
            this.txtNetAmount.Size = new System.Drawing.Size(176, 26);
            this.txtNetAmount.TabIndex = 10;
            // 
            // pnlMain
            // 
            this.pnlMain.BackColor = System.Drawing.Color.White;
            this.pnlMain.Controls.Add(this.pnlBottom);
            this.pnlMain.Controls.Add(this.pnlMiddle);
            this.pnlMain.Controls.Add(this.pnlHeader);
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlMain.Location = new System.Drawing.Point(0, 0);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1343, 696);
            this.pnlMain.TabIndex = 2;
            // 
            // pnlMiddle
            // 
            this.pnlMiddle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlMiddle.Controls.Add(this.pnlPurchaseInvoiceDetail);
            this.pnlMiddle.Controls.Add(this.pnlSearchProduct);
            this.pnlMiddle.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMiddle.Location = new System.Drawing.Point(0, 160);
            this.pnlMiddle.Name = "pnlMiddle";
            this.pnlMiddle.Size = new System.Drawing.Size(1343, 536);
            this.pnlMiddle.TabIndex = 1;
            // 
            // pnlPurchaseInvoiceDetail
            // 
            this.pnlPurchaseInvoiceDetail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlPurchaseInvoiceDetail.Controls.Add(this.dgvPurchaseInvoiceDetail);
            this.pnlPurchaseInvoiceDetail.Controls.Add(this.panel2);
            this.pnlPurchaseInvoiceDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPurchaseInvoiceDetail.Location = new System.Drawing.Point(0, 166);
            this.pnlPurchaseInvoiceDetail.Name = "pnlPurchaseInvoiceDetail";
            this.pnlPurchaseInvoiceDetail.Size = new System.Drawing.Size(1341, 368);
            this.pnlPurchaseInvoiceDetail.TabIndex = 1;
            // 
            // dgvPurchaseInvoiceDetail
            // 
            this.dgvPurchaseInvoiceDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPurchaseInvoiceDetail.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Product_Code,
            this.Product_Name,
            this.Mfg_Date,
            this.Exp_Date,
            this.Purchase_Rate,
            this.MRP,
            this.Qty,
            this.Free_Qty,
            this.Available_Stk_Qty,
            this.Discount_Perc,
            this.Discount_Amt,
            this.Sub_Total,
            this.Net_Amount});
            this.dgvPurchaseInvoiceDetail.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvPurchaseInvoiceDetail.Location = new System.Drawing.Point(0, 41);
            this.dgvPurchaseInvoiceDetail.Name = "dgvPurchaseInvoiceDetail";
            this.dgvPurchaseInvoiceDetail.Size = new System.Drawing.Size(1339, 325);
            this.dgvPurchaseInvoiceDetail.TabIndex = 1;
            // 
            // Product_Code
            // 
            this.Product_Code.HeaderText = "Product Code";
            this.Product_Code.Name = "Product_Code";
            // 
            // Product_Name
            // 
            this.Product_Name.HeaderText = "Product Name";
            this.Product_Name.Name = "Product_Name";
            // 
            // Mfg_Date
            // 
            this.Mfg_Date.HeaderText = "MfgDate";
            this.Mfg_Date.Name = "Mfg_Date";
            // 
            // Exp_Date
            // 
            this.Exp_Date.HeaderText = "Exp Date";
            this.Exp_Date.Name = "Exp_Date";
            // 
            // Purchase_Rate
            // 
            this.Purchase_Rate.HeaderText = "Purchase Rate";
            this.Purchase_Rate.Name = "Purchase_Rate";
            // 
            // MRP
            // 
            this.MRP.HeaderText = "MRP";
            this.MRP.Name = "MRP";
            // 
            // Qty
            // 
            this.Qty.HeaderText = "Qty";
            this.Qty.Name = "Qty";
            // 
            // Free_Qty
            // 
            this.Free_Qty.HeaderText = "Free Qty";
            this.Free_Qty.Name = "Free_Qty";
            // 
            // Available_Stk_Qty
            // 
            this.Available_Stk_Qty.HeaderText = "Available Stk Qty";
            this.Available_Stk_Qty.Name = "Available_Stk_Qty";
            // 
            // Discount_Perc
            // 
            this.Discount_Perc.HeaderText = "Discount(%)";
            this.Discount_Perc.Name = "Discount_Perc";
            // 
            // Discount_Amt
            // 
            this.Discount_Amt.HeaderText = "Discount Amt";
            this.Discount_Amt.Name = "Discount_Amt";
            // 
            // Sub_Total
            // 
            this.Sub_Total.HeaderText = "Sub Total";
            this.Sub_Total.Name = "Sub_Total";
            // 
            // Net_Amount
            // 
            this.Net_Amount.HeaderText = "Net Amount";
            this.Net_Amount.Name = "Net_Amount";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.lblPurchaseInvoiceDetail);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1339, 41);
            this.panel2.TabIndex = 0;
            // 
            // lblPurchaseInvoiceDetail
            // 
            this.lblPurchaseInvoiceDetail.AutoSize = true;
            this.lblPurchaseInvoiceDetail.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPurchaseInvoiceDetail.Location = new System.Drawing.Point(11, 7);
            this.lblPurchaseInvoiceDetail.Name = "lblPurchaseInvoiceDetail";
            this.lblPurchaseInvoiceDetail.Size = new System.Drawing.Size(204, 22);
            this.lblPurchaseInvoiceDetail.TabIndex = 0;
            this.lblPurchaseInvoiceDetail.Text = "Purchase Invoice Detail";
            // 
            // pnlSearchProduct
            // 
            this.pnlSearchProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSearchProduct.Controls.Add(this.dgvVendorDetail);
            this.pnlSearchProduct.Controls.Add(this.txtPurchaseRate);
            this.pnlSearchProduct.Controls.Add(this.lblPurchaseRate);
            this.pnlSearchProduct.Controls.Add(this.txtDiscAmt);
            this.pnlSearchProduct.Controls.Add(this.lblDiscAmt);
            this.pnlSearchProduct.Controls.Add(this.txtDisPer);
            this.pnlSearchProduct.Controls.Add(this.lblDiscountPer);
            this.pnlSearchProduct.Controls.Add(this.txtFreeQty);
            this.pnlSearchProduct.Controls.Add(this.lblFreeQty);
            this.pnlSearchProduct.Controls.Add(this.txtQty);
            this.pnlSearchProduct.Controls.Add(this.lblQty);
            this.pnlSearchProduct.Controls.Add(this.groupBoxAvlQty);
            this.pnlSearchProduct.Controls.Add(this.btnProductAdd);
            this.pnlSearchProduct.Controls.Add(this.textBox2);
            this.pnlSearchProduct.Controls.Add(this.lblMRP);
            this.pnlSearchProduct.Controls.Add(this.dateExp);
            this.pnlSearchProduct.Controls.Add(this.lblExpDate);
            this.pnlSearchProduct.Controls.Add(this.dateMfg);
            this.pnlSearchProduct.Controls.Add(this.lblMfgDate);
            this.pnlSearchProduct.Controls.Add(this.txtProductCode);
            this.pnlSearchProduct.Controls.Add(this.lblProductCode);
            this.pnlSearchProduct.Controls.Add(this.textBox1);
            this.pnlSearchProduct.Controls.Add(this.lblProductName);
            this.pnlSearchProduct.Controls.Add(this.rdbProductCode);
            this.pnlSearchProduct.Controls.Add(this.rdbProductName);
            this.pnlSearchProduct.Controls.Add(this.lblFilterType);
            this.pnlSearchProduct.Controls.Add(this.pnlSearchProductTitle);
            this.pnlSearchProduct.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSearchProduct.Location = new System.Drawing.Point(0, 0);
            this.pnlSearchProduct.Name = "pnlSearchProduct";
            this.pnlSearchProduct.Size = new System.Drawing.Size(1341, 166);
            this.pnlSearchProduct.TabIndex = 0;
            // 
            // dgvVendorDetail
            // 
            this.dgvVendorDetail.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvVendorDetail.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvVendorDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvVendorDetail.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Vendor_Code,
            this.Vendor_Name,
            this.Vendor_Address,
            this.Vendor_Type});
            this.dgvVendorDetail.Location = new System.Drawing.Point(425, 4);
            this.dgvVendorDetail.Name = "dgvVendorDetail";
            this.dgvVendorDetail.Size = new System.Drawing.Size(533, 203);
            this.dgvVendorDetail.TabIndex = 15;
            this.dgvVendorDetail.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvVendorDetail_CellContentClick);
            // 
            // Vendor_Code
            // 
            this.Vendor_Code.DataPropertyName = "Vendor_Code";
            this.Vendor_Code.HeaderText = "Vendor_Code";
            this.Vendor_Code.Name = "Vendor_Code";
            // 
            // Vendor_Name
            // 
            this.Vendor_Name.DataPropertyName = "Vendor_Name";
            this.Vendor_Name.HeaderText = "Vendor_Name";
            this.Vendor_Name.Name = "Vendor_Name";
            // 
            // Vendor_Address
            // 
            this.Vendor_Address.DataPropertyName = "Vendor_Address";
            this.Vendor_Address.HeaderText = "Vendor_Address";
            this.Vendor_Address.Name = "Vendor_Address";
            // 
            // Vendor_Type
            // 
            this.Vendor_Type.DataPropertyName = "Vendor_Type";
            this.Vendor_Type.HeaderText = "VendorType";
            this.Vendor_Type.Name = "Vendor_Type";
            // 
            // txtPurchaseRate
            // 
            this.txtPurchaseRate.Location = new System.Drawing.Point(452, 114);
            this.txtPurchaseRate.Name = "txtPurchaseRate";
            this.txtPurchaseRate.Size = new System.Drawing.Size(64, 26);
            this.txtPurchaseRate.TabIndex = 27;
            // 
            // lblPurchaseRate
            // 
            this.lblPurchaseRate.AutoSize = true;
            this.lblPurchaseRate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPurchaseRate.Location = new System.Drawing.Point(448, 86);
            this.lblPurchaseRate.Name = "lblPurchaseRate";
            this.lblPurchaseRate.Size = new System.Drawing.Size(37, 19);
            this.lblPurchaseRate.TabIndex = 26;
            this.lblPurchaseRate.Text = "Rate";
            // 
            // txtDiscAmt
            // 
            this.txtDiscAmt.Location = new System.Drawing.Point(802, 114);
            this.txtDiscAmt.Name = "txtDiscAmt";
            this.txtDiscAmt.Size = new System.Drawing.Size(64, 26);
            this.txtDiscAmt.TabIndex = 25;
            // 
            // lblDiscAmt
            // 
            this.lblDiscAmt.AutoSize = true;
            this.lblDiscAmt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiscAmt.Location = new System.Drawing.Point(802, 86);
            this.lblDiscAmt.Name = "lblDiscAmt";
            this.lblDiscAmt.Size = new System.Drawing.Size(65, 19);
            this.lblDiscAmt.TabIndex = 24;
            this.lblDiscAmt.Text = "Disc Amt";
            // 
            // txtDisPer
            // 
            this.txtDisPer.Location = new System.Drawing.Point(732, 115);
            this.txtDisPer.Name = "txtDisPer";
            this.txtDisPer.Size = new System.Drawing.Size(64, 26);
            this.txtDisPer.TabIndex = 23;
            // 
            // lblDiscountPer
            // 
            this.lblDiscountPer.AutoSize = true;
            this.lblDiscountPer.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiscountPer.Location = new System.Drawing.Point(730, 86);
            this.lblDiscountPer.Name = "lblDiscountPer";
            this.lblDiscountPer.Size = new System.Drawing.Size(59, 19);
            this.lblDiscountPer.TabIndex = 22;
            this.lblDiscountPer.Text = "Disc(%)";
            // 
            // txtFreeQty
            // 
            this.txtFreeQty.Location = new System.Drawing.Point(662, 115);
            this.txtFreeQty.Name = "txtFreeQty";
            this.txtFreeQty.Size = new System.Drawing.Size(64, 26);
            this.txtFreeQty.TabIndex = 21;
            // 
            // lblFreeQty
            // 
            this.lblFreeQty.AutoSize = true;
            this.lblFreeQty.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFreeQty.Location = new System.Drawing.Point(658, 86);
            this.lblFreeQty.Name = "lblFreeQty";
            this.lblFreeQty.Size = new System.Drawing.Size(64, 19);
            this.lblFreeQty.TabIndex = 20;
            this.lblFreeQty.Text = "Free Qty";
            // 
            // txtQty
            // 
            this.txtQty.Location = new System.Drawing.Point(592, 115);
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(64, 26);
            this.txtQty.TabIndex = 19;
            // 
            // lblQty
            // 
            this.lblQty.AutoSize = true;
            this.lblQty.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQty.Location = new System.Drawing.Point(588, 86);
            this.lblQty.Name = "lblQty";
            this.lblQty.Size = new System.Drawing.Size(32, 19);
            this.lblQty.TabIndex = 18;
            this.lblQty.Text = "Qty";
            // 
            // groupBoxAvlQty
            // 
            this.groupBoxAvlQty.Controls.Add(this.lblAvlQty);
            this.groupBoxAvlQty.Controls.Add(this.label2);
            this.groupBoxAvlQty.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxAvlQty.Location = new System.Drawing.Point(874, 74);
            this.groupBoxAvlQty.Name = "groupBoxAvlQty";
            this.groupBoxAvlQty.Size = new System.Drawing.Size(200, 66);
            this.groupBoxAvlQty.TabIndex = 17;
            this.groupBoxAvlQty.TabStop = false;
            this.groupBoxAvlQty.Text = "Stock";
            // 
            // lblAvlQty
            // 
            this.lblAvlQty.AutoSize = true;
            this.lblAvlQty.Location = new System.Drawing.Point(121, 41);
            this.lblAvlQty.Name = "lblAvlQty";
            this.lblAvlQty.Size = new System.Drawing.Size(17, 19);
            this.lblAvlQty.TabIndex = 1;
            this.lblAvlQty.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 19);
            this.label2.TabIndex = 0;
            this.label2.Text = "Available Qty :";
            // 
            // btnProductAdd
            // 
            this.btnProductAdd.BackColor = System.Drawing.Color.White;
            this.btnProductAdd.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProductAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnProductAdd.Image")));
            this.btnProductAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnProductAdd.Location = new System.Drawing.Point(1082, 102);
            this.btnProductAdd.Name = "btnProductAdd";
            this.btnProductAdd.Size = new System.Drawing.Size(64, 32);
            this.btnProductAdd.TabIndex = 16;
            this.btnProductAdd.Text = "Add";
            this.btnProductAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnProductAdd.UseVisualStyleBackColor = false;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(522, 115);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(64, 26);
            this.textBox2.TabIndex = 13;
            // 
            // lblMRP
            // 
            this.lblMRP.AutoSize = true;
            this.lblMRP.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMRP.Location = new System.Drawing.Point(519, 86);
            this.lblMRP.Name = "lblMRP";
            this.lblMRP.Size = new System.Drawing.Size(42, 19);
            this.lblMRP.TabIndex = 12;
            this.lblMRP.Text = "MRP";
            // 
            // dateExp
            // 
            this.dateExp.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateExp.Location = new System.Drawing.Point(339, 115);
            this.dateExp.Name = "dateExp";
            this.dateExp.Size = new System.Drawing.Size(109, 26);
            this.dateExp.TabIndex = 11;
            // 
            // lblExpDate
            // 
            this.lblExpDate.AutoSize = true;
            this.lblExpDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExpDate.Location = new System.Drawing.Point(336, 86);
            this.lblExpDate.Name = "lblExpDate";
            this.lblExpDate.Size = new System.Drawing.Size(66, 19);
            this.lblExpDate.TabIndex = 10;
            this.lblExpDate.Text = "Exp Date";
            // 
            // dateMfg
            // 
            this.dateMfg.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateMfg.Location = new System.Drawing.Point(224, 115);
            this.dateMfg.Name = "dateMfg";
            this.dateMfg.Size = new System.Drawing.Size(109, 26);
            this.dateMfg.TabIndex = 9;
            // 
            // lblMfgDate
            // 
            this.lblMfgDate.AutoSize = true;
            this.lblMfgDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMfgDate.Location = new System.Drawing.Point(221, 86);
            this.lblMfgDate.Name = "lblMfgDate";
            this.lblMfgDate.Size = new System.Drawing.Size(67, 19);
            this.lblMfgDate.TabIndex = 8;
            this.lblMfgDate.Text = "Mfg Date";
            // 
            // txtProductCode
            // 
            this.txtProductCode.Location = new System.Drawing.Point(146, 115);
            this.txtProductCode.Name = "txtProductCode";
            this.txtProductCode.Size = new System.Drawing.Size(72, 26);
            this.txtProductCode.TabIndex = 7;
            // 
            // lblProductCode
            // 
            this.lblProductCode.AutoSize = true;
            this.lblProductCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductCode.Location = new System.Drawing.Point(145, 86);
            this.lblProductCode.Name = "lblProductCode";
            this.lblProductCode.Size = new System.Drawing.Size(43, 19);
            this.lblProductCode.TabIndex = 6;
            this.lblProductCode.Text = "Code";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(15, 115);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(125, 26);
            this.textBox1.TabIndex = 5;
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProductName.Location = new System.Drawing.Point(15, 86);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(102, 19);
            this.lblProductName.TabIndex = 4;
            this.lblProductName.Text = "Product Name ";
            // 
            // rdbProductCode
            // 
            this.rdbProductCode.AutoSize = true;
            this.rdbProductCode.Location = new System.Drawing.Point(239, 49);
            this.rdbProductCode.Name = "rdbProductCode";
            this.rdbProductCode.Size = new System.Drawing.Size(117, 23);
            this.rdbProductCode.TabIndex = 3;
            this.rdbProductCode.TabStop = true;
            this.rdbProductCode.Text = "Product Code ";
            this.rdbProductCode.UseVisualStyleBackColor = true;
            // 
            // rdbProductName
            // 
            this.rdbProductName.AutoSize = true;
            this.rdbProductName.Location = new System.Drawing.Point(113, 49);
            this.rdbProductName.Name = "rdbProductName";
            this.rdbProductName.Size = new System.Drawing.Size(120, 23);
            this.rdbProductName.TabIndex = 2;
            this.rdbProductName.TabStop = true;
            this.rdbProductName.Text = "Product Name ";
            this.rdbProductName.UseVisualStyleBackColor = true;
            // 
            // lblFilterType
            // 
            this.lblFilterType.AutoSize = true;
            this.lblFilterType.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFilterType.Location = new System.Drawing.Point(10, 51);
            this.lblFilterType.Name = "lblFilterType";
            this.lblFilterType.Size = new System.Drawing.Size(95, 19);
            this.lblFilterType.TabIndex = 1;
            this.lblFilterType.Text = "Filter Type  :";
            // 
            // pnlSearchProductTitle
            // 
            this.pnlSearchProductTitle.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pnlSearchProductTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSearchProductTitle.Controls.Add(this.lblSearchProduct);
            this.pnlSearchProductTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlSearchProductTitle.Location = new System.Drawing.Point(0, 0);
            this.pnlSearchProductTitle.Name = "pnlSearchProductTitle";
            this.pnlSearchProductTitle.Size = new System.Drawing.Size(1339, 35);
            this.pnlSearchProductTitle.TabIndex = 0;
            // 
            // lblSearchProduct
            // 
            this.lblSearchProduct.AutoSize = true;
            this.lblSearchProduct.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchProduct.Location = new System.Drawing.Point(11, 3);
            this.lblSearchProduct.Name = "lblSearchProduct";
            this.lblSearchProduct.Size = new System.Drawing.Size(137, 22);
            this.lblSearchProduct.TabIndex = 0;
            this.lblSearchProduct.Text = "Search Product";
            // 
            // pnlHeader
            // 
            this.pnlHeader.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlHeader.Controls.Add(this.comboVendorType);
            this.pnlHeader.Controls.Add(this.lblVendorType);
            this.pnlHeader.Controls.Add(this.txtVendorAddress);
            this.pnlHeader.Controls.Add(this.txtVendorName);
            this.pnlHeader.Controls.Add(this.txtVendorCode);
            this.pnlHeader.Controls.Add(this.lblVendorAddress);
            this.pnlHeader.Controls.Add(this.lblVendorName);
            this.pnlHeader.Controls.Add(this.lblVendorCode);
            this.pnlHeader.Controls.Add(this.dueDatePurchaseInvoice);
            this.pnlHeader.Controls.Add(this.datePurchaseInvoice);
            this.pnlHeader.Controls.Add(this.lblPurchaseInvoiceDueDate);
            this.pnlHeader.Controls.Add(this.lblPurchaseInvoiceDate);
            this.pnlHeader.Controls.Add(this.txtPurchaseInvoiceNo);
            this.pnlHeader.Controls.Add(this.lblPurchaseInvoiceNo);
            this.pnlHeader.Controls.Add(this.pnlPurchaseInvoiceHeader);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Name = "pnlHeader";
            this.pnlHeader.Size = new System.Drawing.Size(1343, 160);
            this.pnlHeader.TabIndex = 0;
            // 
            // comboVendorType
            // 
            this.comboVendorType.Enabled = false;
            this.comboVendorType.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboVendorType.FormattingEnabled = true;
            this.comboVendorType.Location = new System.Drawing.Point(873, 38);
            this.comboVendorType.Name = "comboVendorType";
            this.comboVendorType.Size = new System.Drawing.Size(163, 27);
            this.comboVendorType.TabIndex = 14;
            // 
            // lblVendorType
            // 
            this.lblVendorType.AutoSize = true;
            this.lblVendorType.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendorType.Location = new System.Drawing.Point(773, 46);
            this.lblVendorType.Name = "lblVendorType";
            this.lblVendorType.Size = new System.Drawing.Size(94, 19);
            this.lblVendorType.TabIndex = 13;
            this.lblVendorType.Text = "Vendor Type :";
            // 
            // txtVendorAddress
            // 
            this.txtVendorAddress.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVendorAddress.Location = new System.Drawing.Point(557, 113);
            this.txtVendorAddress.Name = "txtVendorAddress";
            this.txtVendorAddress.ReadOnly = true;
            this.txtVendorAddress.Size = new System.Drawing.Size(182, 26);
            this.txtVendorAddress.TabIndex = 12;
            // 
            // txtVendorName
            // 
            this.txtVendorName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVendorName.Location = new System.Drawing.Point(557, 78);
            this.txtVendorName.Name = "txtVendorName";
            this.txtVendorName.ReadOnly = true;
            this.txtVendorName.Size = new System.Drawing.Size(182, 26);
            this.txtVendorName.TabIndex = 11;
            // 
            // txtVendorCode
            // 
            this.txtVendorCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVendorCode.Location = new System.Drawing.Point(557, 43);
            this.txtVendorCode.Name = "txtVendorCode";
            this.txtVendorCode.Size = new System.Drawing.Size(182, 26);
            this.txtVendorCode.TabIndex = 10;
            this.txtVendorCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtVendorCode_KeyDown);
            this.txtVendorCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtVendorCode_KeyPress);
            this.txtVendorCode.Leave += new System.EventHandler(this.txtVendorCode_Leave);
            // 
            // lblVendorAddress
            // 
            this.lblVendorAddress.AutoSize = true;
            this.lblVendorAddress.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendorAddress.Location = new System.Drawing.Point(431, 120);
            this.lblVendorAddress.Name = "lblVendorAddress";
            this.lblVendorAddress.Size = new System.Drawing.Size(110, 19);
            this.lblVendorAddress.TabIndex = 9;
            this.lblVendorAddress.Text = "Vendor Address:";
            // 
            // lblVendorName
            // 
            this.lblVendorName.AutoSize = true;
            this.lblVendorName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendorName.Location = new System.Drawing.Point(431, 81);
            this.lblVendorName.Name = "lblVendorName";
            this.lblVendorName.Size = new System.Drawing.Size(101, 19);
            this.lblVendorName.TabIndex = 8;
            this.lblVendorName.Text = "Vendor Name :";
            // 
            // lblVendorCode
            // 
            this.lblVendorCode.AutoSize = true;
            this.lblVendorCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVendorCode.Location = new System.Drawing.Point(431, 45);
            this.lblVendorCode.Name = "lblVendorCode";
            this.lblVendorCode.Size = new System.Drawing.Size(102, 19);
            this.lblVendorCode.TabIndex = 7;
            this.lblVendorCode.Text = "Vendor Code  :";
            // 
            // dueDatePurchaseInvoice
            // 
            this.dueDatePurchaseInvoice.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dueDatePurchaseInvoice.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dueDatePurchaseInvoice.Location = new System.Drawing.Point(195, 115);
            this.dueDatePurchaseInvoice.Name = "dueDatePurchaseInvoice";
            this.dueDatePurchaseInvoice.Size = new System.Drawing.Size(193, 26);
            this.dueDatePurchaseInvoice.TabIndex = 6;
            // 
            // datePurchaseInvoice
            // 
            this.datePurchaseInvoice.Enabled = false;
            this.datePurchaseInvoice.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datePurchaseInvoice.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datePurchaseInvoice.Location = new System.Drawing.Point(195, 79);
            this.datePurchaseInvoice.Name = "datePurchaseInvoice";
            this.datePurchaseInvoice.Size = new System.Drawing.Size(193, 26);
            this.datePurchaseInvoice.TabIndex = 5;
            // 
            // lblPurchaseInvoiceDueDate
            // 
            this.lblPurchaseInvoiceDueDate.AutoSize = true;
            this.lblPurchaseInvoiceDueDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPurchaseInvoiceDueDate.Location = new System.Drawing.Point(16, 115);
            this.lblPurchaseInvoiceDueDate.Name = "lblPurchaseInvoiceDueDate";
            this.lblPurchaseInvoiceDueDate.Size = new System.Drawing.Size(78, 19);
            this.lblPurchaseInvoiceDueDate.TabIndex = 4;
            this.lblPurchaseInvoiceDueDate.Text = "Due Date  :";
            // 
            // lblPurchaseInvoiceDate
            // 
            this.lblPurchaseInvoiceDate.AutoSize = true;
            this.lblPurchaseInvoiceDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPurchaseInvoiceDate.Location = new System.Drawing.Point(16, 85);
            this.lblPurchaseInvoiceDate.Name = "lblPurchaseInvoiceDate";
            this.lblPurchaseInvoiceDate.Size = new System.Drawing.Size(156, 19);
            this.lblPurchaseInvoiceDate.TabIndex = 3;
            this.lblPurchaseInvoiceDate.Text = "Purchase Invoice Date  :";
            // 
            // txtPurchaseInvoiceNo
            // 
            this.txtPurchaseInvoiceNo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPurchaseInvoiceNo.Location = new System.Drawing.Point(195, 45);
            this.txtPurchaseInvoiceNo.Name = "txtPurchaseInvoiceNo";
            this.txtPurchaseInvoiceNo.ReadOnly = true;
            this.txtPurchaseInvoiceNo.Size = new System.Drawing.Size(193, 26);
            this.txtPurchaseInvoiceNo.TabIndex = 2;
            // 
            // lblPurchaseInvoiceNo
            // 
            this.lblPurchaseInvoiceNo.AutoSize = true;
            this.lblPurchaseInvoiceNo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPurchaseInvoiceNo.Location = new System.Drawing.Point(15, 52);
            this.lblPurchaseInvoiceNo.Name = "lblPurchaseInvoiceNo";
            this.lblPurchaseInvoiceNo.Size = new System.Drawing.Size(147, 19);
            this.lblPurchaseInvoiceNo.TabIndex = 1;
            this.lblPurchaseInvoiceNo.Text = "Purchase Invoice No  :";
            // 
            // pnlPurchaseInvoiceHeader
            // 
            this.pnlPurchaseInvoiceHeader.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.pnlPurchaseInvoiceHeader.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlPurchaseInvoiceHeader.Controls.Add(this.lblPurchaseInvoice);
            this.pnlPurchaseInvoiceHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlPurchaseInvoiceHeader.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlPurchaseInvoiceHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlPurchaseInvoiceHeader.Name = "pnlPurchaseInvoiceHeader";
            this.pnlPurchaseInvoiceHeader.Size = new System.Drawing.Size(1341, 33);
            this.pnlPurchaseInvoiceHeader.TabIndex = 0;
            // 
            // lblPurchaseInvoice
            // 
            this.lblPurchaseInvoice.AutoSize = true;
            this.lblPurchaseInvoice.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPurchaseInvoice.Location = new System.Drawing.Point(10, 7);
            this.lblPurchaseInvoice.Name = "lblPurchaseInvoice";
            this.lblPurchaseInvoice.Size = new System.Drawing.Size(150, 22);
            this.lblPurchaseInvoice.TabIndex = 0;
            this.lblPurchaseInvoice.Text = "Purchase Invoice";
            // 
            // frmPurcahseInvoice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1343, 696);
            this.Controls.Add(this.pnlMain);
            this.Name = "frmPurcahseInvoice";
            this.Text = "PurcahseInvoice";
            this.Load += new System.EventHandler(this.frmPurcahseInvoice_Load);
            this.pnlBottom.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.pnlCalculation.ResumeLayout(false);
            this.pnlRight.ResumeLayout(false);
            this.pnlRight.PerformLayout();
            this.pnlMain.ResumeLayout(false);
            this.pnlMiddle.ResumeLayout(false);
            this.pnlPurchaseInvoiceDetail.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPurchaseInvoiceDetail)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnlSearchProduct.ResumeLayout(false);
            this.pnlSearchProduct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvVendorDetail)).EndInit();
            this.groupBoxAvlQty.ResumeLayout(false);
            this.groupBoxAvlQty.PerformLayout();
            this.pnlSearchProductTitle.ResumeLayout(false);
            this.pnlSearchProductTitle.PerformLayout();
            this.pnlHeader.ResumeLayout(false);
            this.pnlHeader.PerformLayout();
            this.pnlPurchaseInvoiceHeader.ResumeLayout(false);
            this.pnlPurchaseInvoiceHeader.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Panel pnlBottom;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Panel pnlCalculation;
        private System.Windows.Forms.Panel pnlRight;
        private System.Windows.Forms.TextBox txtGrossAmount;
        private System.Windows.Forms.Label lblGrossAmt;
        private System.Windows.Forms.TextBox txtDiscountAmtPercentage;
        private System.Windows.Forms.Label lblDiscountAmtPer;
        private System.Windows.Forms.TextBox txtDiscountAmt;
        private System.Windows.Forms.TextBox txtRoundOff;
        private System.Windows.Forms.Label lblRoundOff;
        private System.Windows.Forms.Label lblNetAmount;
        private System.Windows.Forms.TextBox txtNetAmount;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlMiddle;
        private System.Windows.Forms.Panel pnlPurchaseInvoiceDetail;
        private System.Windows.Forms.DataGridView dgvPurchaseInvoiceDetail;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Mfg_Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn Exp_Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn Purchase_Rate;
        private System.Windows.Forms.DataGridViewTextBoxColumn MRP;
        private System.Windows.Forms.DataGridViewTextBoxColumn Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Free_Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Available_Stk_Qty;
        private System.Windows.Forms.DataGridViewTextBoxColumn Discount_Perc;
        private System.Windows.Forms.DataGridViewTextBoxColumn Discount_Amt;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sub_Total;
        private System.Windows.Forms.DataGridViewTextBoxColumn Net_Amount;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblPurchaseInvoiceDetail;
        private System.Windows.Forms.Panel pnlSearchProduct;
        private System.Windows.Forms.TextBox txtPurchaseRate;
        private System.Windows.Forms.Label lblPurchaseRate;
        private System.Windows.Forms.TextBox txtDiscAmt;
        private System.Windows.Forms.Label lblDiscAmt;
        private System.Windows.Forms.TextBox txtDisPer;
        private System.Windows.Forms.Label lblDiscountPer;
        private System.Windows.Forms.TextBox txtFreeQty;
        private System.Windows.Forms.Label lblFreeQty;
        private System.Windows.Forms.TextBox txtQty;
        private System.Windows.Forms.Label lblQty;
        private System.Windows.Forms.GroupBox groupBoxAvlQty;
        private System.Windows.Forms.Label lblAvlQty;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnProductAdd;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lblMRP;
        private System.Windows.Forms.DateTimePicker dateExp;
        private System.Windows.Forms.Label lblExpDate;
        private System.Windows.Forms.DateTimePicker dateMfg;
        private System.Windows.Forms.Label lblMfgDate;
        private System.Windows.Forms.TextBox txtProductCode;
        private System.Windows.Forms.Label lblProductCode;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.RadioButton rdbProductCode;
        private System.Windows.Forms.RadioButton rdbProductName;
        private System.Windows.Forms.Label lblFilterType;
        private System.Windows.Forms.Panel pnlSearchProductTitle;
        private System.Windows.Forms.Label lblSearchProduct;
        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.ComboBox comboVendorType;
        private System.Windows.Forms.Label lblVendorType;
        private System.Windows.Forms.TextBox txtVendorAddress;
        private System.Windows.Forms.TextBox txtVendorName;
        private System.Windows.Forms.TextBox txtVendorCode;
        private System.Windows.Forms.Label lblVendorAddress;
        private System.Windows.Forms.Label lblVendorName;
        private System.Windows.Forms.Label lblVendorCode;
        private System.Windows.Forms.DateTimePicker dueDatePurchaseInvoice;
        private System.Windows.Forms.DateTimePicker datePurchaseInvoice;
        private System.Windows.Forms.Label lblPurchaseInvoiceDueDate;
        private System.Windows.Forms.Label lblPurchaseInvoiceDate;
        private System.Windows.Forms.TextBox txtPurchaseInvoiceNo;
        private System.Windows.Forms.Label lblPurchaseInvoiceNo;
        private System.Windows.Forms.Panel pnlPurchaseInvoiceHeader;
        private System.Windows.Forms.Label lblPurchaseInvoice;
        private System.Windows.Forms.DataGridView dgvVendorDetail;
        private System.Windows.Forms.DataGridViewTextBoxColumn Vendor_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn Vendor_Name;
        private System.Windows.Forms.DataGridViewTextBoxColumn Vendor_Address;
        private System.Windows.Forms.DataGridViewTextBoxColumn Vendor_Type;
    }
}