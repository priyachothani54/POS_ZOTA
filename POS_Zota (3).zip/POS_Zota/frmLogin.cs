﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BAL;
using DAL;
//using Model;


namespace POS_Zota
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void linkLblForgetPwd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            /*
             * Forget Before password Username fill complusory
             */
            if (string.IsNullOrWhiteSpace(txtUserName.Text.Trim()))
            {
                MessageBox.Show("Please enter your username before resetting password.");
                return;
            }

            string username = txtUserName.Text.Trim();

            frmForgetPassword f1 = new frmForgetPassword(username); /*pass username here*/
            f1.ShowDialog();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtUserName.Text.Trim()))
                {
                    txtUserName.Focus();
                    clsCommon.ShowErrorMessage("Please Enter User Name");
                    return;
                }
                else if (string.IsNullOrEmpty(txtPassword.Text.Trim()))
                {
                    txtPassword.Focus();
                    clsCommon.ShowErrorMessage("Please Enter Password");
                    return;
                }

                clsUserLoginBAL obj = new clsUserLoginBAL();
                obj.SP_STATUS = "CheckLogin";
                obj.User_Name = txtUserName.Text.Trim();
                obj.User_Password = EncryptString.Encrypt(txtPassword.Text.Trim());
                DataTable dtGettLogin = obj.GetDataTable(obj);


                if (dtGettLogin.Rows.Count > 0)
                {
                    string storedHash = dtGettLogin.Rows[0]["Password"].ToString();

                   

                    if (EncryptString.Decrypt(storedHash) == txtPassword.Text.Trim())
                    {
                        //MessageBox.Show("Login Successful!");
                        this.Hide();
                        frmDashboard nextPage = new frmDashboard();
                        nextPage.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Invalid Password");
                        txtPassword.Clear();
                    }
                }
                else
                {
                    clsCommon.ShowErrorMessage("Invalid User Name or Password");
                    txtPassword.Text = String.Empty;
                    txtPassword.Focus();
                    txtUserName.Clear();                  
                    return;
                }
                frmDashboard f1 = new frmDashboard();
                f1.ShowDialog();
                this.Close();
            }
            catch
            {
                MessageBox.Show("Showing Error Message");
            }
        }
  
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
