﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_Zota
{
    public partial class frmDashboard : Form
    {
        public frmDashboard()
        {
            InitializeComponent();
        }

        private void btnAddPurchaseInvoice_Click(object sender, EventArgs e)
        {
            frmPurcahseInvoice p1 = new frmPurcahseInvoice();
            p1.ShowDialog();
        }

        private void btnAddSalesInvoice_Click(object sender, EventArgs e)
        {
            frmSalesInvoice s1 =  new frmSalesInvoice();
            s1.ShowDialog();

        }

        private void frmDashboard_Load(object sender, EventArgs e)
        {

        }
    }
}
