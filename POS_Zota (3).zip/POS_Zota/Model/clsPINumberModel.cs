﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class clsPINumberModel
    {
        public string SP_STATUS { get; set; }
        public int PurchaseInvoice_No { get; set; }
    }
}
