﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BAL;
using DAL;
using Model;

namespace POS_Zota
{
    public partial class frmPurcahseInvoice : Form
    {
        public frmPurcahseInvoice()
        {
            InitializeComponent();
            Vendordata();
       
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            frmDashboard d1 = new frmDashboard();
            d1.ShowDialog();
        }

        private void frmPurcahseInvoice_Load(object sender, EventArgs e)
        {
            PurchaseInvoiceNumber();
            dgvVendorDetail.Visible = false;
        }

        void PurchaseInvoiceNumber()
        {
            clsPINumberBAL obj = new clsPINumberBAL();
            obj.SP_STATUS = "PurchaseInvoiceNumber";

            DataTable dt = obj.GetDataTable(obj);

            if (dt != null && dt.Rows.Count > 0)
            {
                txtPurchaseInvoiceNo.Text = dt.Rows[0]["PurchaseInvoiceNumber"].ToString();
            }
        }

        private void txtVendorCode_KeyDown(object sender, KeyEventArgs e)
        {
            // Allow only Backspace and Enter keys
            if (e.KeyCode != Keys.Back && e.KeyCode != Keys.Enter)
            {
                e.SuppressKeyPress = true; // Blocks other keys
            }

            if (e.KeyCode == Keys.Enter)
            {
               dgvVendorDetail.Visible = true;
            }
        }

        void Vendordata()
        {
            clsVendorDataBal obj = new clsVendorDataBal();
            obj.SP_Status = "VendorDetail";

            DataTable dt = obj.GetDataTable(obj);
            dgvVendorDetail.DataSource = dt;
        }

       //
        private void dgvVendorDetail_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dgvVendorDetail.Rows.Count)
            {
                //1...Continue
                DataGridViewRow row = dgvVendorDetail.Rows[e.RowIndex];

                txtVendorCode.Text = row.Cells["Vendor_Code"].Value?.ToString() ?? string.Empty;
                txtVendorName.Text = row.Cells["Vendor_Name"].Value?.ToString() ?? string.Empty;
                txtVendorAddress.Text = row.Cells["Vendor_Address"].Value?.ToString() ?? string.Empty;
                comboVendorType.Text = row.Cells["Vendor_Type"].Value?.ToString() ?? string.Empty;
                dgvVendorDetail.Visible = false;
            }
        }

        
        void ClearVendorData()
        {
            txtVendorAddress.Clear();
            txtVendorCode.Clear();
            txtVendorName.Clear();
            comboVendorType.Text = string.Empty;
            comboVendorType.SelectedIndex = -1;
        }

        private void txtVendorCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            ClearVendorData();
        }

        private void txtVendorCode_Leave(object sender, EventArgs e)
        {
            dgvVendorDetail.Visible = false;
        }
    }
}

