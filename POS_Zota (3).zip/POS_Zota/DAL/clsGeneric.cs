﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;

namespace DAL
{
    public class clsGeneric
    {
        private static readonly object lockobject = new object();
        private static SqlConnection Con = null;
        private static SqlCommand cmd = null;

        /* ==============================
         * 1. Connection Helpers
         * ============================== */

        private static void GetConnection()
        {
            lock (lockobject)
            {
                if (Con == null)
                {
                    string Connectionstring = "Data Source=DPC16;Initial Catalog=InvoiceMaster; Persist Security Info=True;User ID=sa;Password=Ethics@123;Max Pool Size=1000;Pooling=true;Connect Timeout=200;";
                    Con = new SqlConnection(Connectionstring);    
                }
                if (Con.State == ConnectionState.Closed)
                {
                    Con.Open();
                }
            }
        }

        private static SqlCommand GetCommand()
        {
            lock (lockobject)
            {
                GetConnection();
                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.Connection = Con;
                return sqlCmd;
            }
        }


        public static SqlParameter GetParameter(string parameterName, DbType dbType, object val)
        {
            lock (lockobject)
            {
                SqlParameter param = new SqlParameter
                {
                    ParameterName = parameterName,
                    DbType = dbType
                };
                if (val == null || val == DBNull.Value)
                {
                    param.Value = DBNull.Value;
                }
                else
                {
                    param.Value = val;
                }
                return param;
            }
        }
        public static SqlParameter GetParameter(string parameterName, object val)
        {
            lock (lockobject)
            {
                SqlParameter param = new SqlParameter
                {
                    ParameterName = parameterName//,
                    //DbType = dbType
                };
                if (val == null || val == DBNull.Value)
                {
                    param.Value = DBNull.Value;
                }
                else
                {
                    param.Value = val;
                }
                return param;
            }
        }
        public static SqlParameter GetParameter(string parameterName, SqlDbType sqldbType, object val)
        {
            lock (lockobject)
            {
                SqlParameter param = new SqlParameter
                {
                    ParameterName = parameterName,
                    SqlDbType = sqldbType
                };
                if (val == null || val == DBNull.Value)
                {
                    param.Value = DBNull.Value;
                }
                else
                {
                    param.Value = val;
                }
                return param;
            }
        }

    
        //public static DataTable GetDataTable(string commandText, SqlParameter[] param, SqlTransaction transDb = null)
        //{
        //    try
        //    {
        //        lock (lockobject)
        //        {
        //            cmd = GetCommand();
        //            cmd.CommandText = commandText;
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.Parameters.AddRange(param);
        //            if (transDb != null)
        //            {
        //                cmd.Transaction = transDb;
        //            }
        //            SqlDataAdapter da = new SqlDataAdapter(cmd);
        //            DataTable dt = new DataTable();
        //            da.Fill(dt);
        //            return dt;
        //        }
        //    }
        //    catch (Exception EX)
        //    {
        //        throw EX.InnerException;
        //    }
        //}

        //Get Single Value     
        public static object GetSingleValue(string commandText, SqlParameter[] Param, SqlTransaction transDb = null)
        {
            try
            {
                lock (lockobject)
                {
                    object obj = null;
                    cmd = GetCommand();
                    cmd.CommandText = commandText;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddRange(Param);
                    if (transDb != null)
                    {
                        cmd.Transaction = transDb;
                    }
                    obj = cmd.ExecuteScalar();
                    return obj;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataTable GetDataTable(string commandText, SqlParameter[] param, SqlTransaction transDb = null)
        {
            lock (lockobject)
            {
                cmd = GetCommand();
                cmd.CommandText = commandText;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Clear();
                cmd.Parameters.AddRange(param);  // Directly use the param instead of calling GetParameter

                if (transDb != null)
                    cmd.Transaction = transDb;

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }
    }
}
