﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAL
{
    public class clsVendorDataDal
    {
        public static DataTable GetDataTable(SqlParameter[] Param)
        {
            return clsGeneric.GetDataTable("SP_VendorDetial", Param);
        }
    }
}
