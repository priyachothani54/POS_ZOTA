﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DAL
{
    public class clsPINumberDAL
    {
        public static DataTable GetDataTable(SqlParameter[] Param)
        {
            return clsGeneric.GetDataTable("SP_PurchaseInvoiceNumber", Param);
        }

        public static object GetSingleValue(SqlParameter[] Param)
        {
            return clsGeneric.GetSingleValue("SP_PurchaseInvoiceNumber", Param);
        }
    }
}
