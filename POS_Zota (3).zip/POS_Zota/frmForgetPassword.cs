﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAL;
using BAL;
using Model;

namespace POS_Zota
{
    public partial class frmForgetPassword : Form
    {
        public frmForgetPassword()
        {
            InitializeComponent();
        }

        /*
         *  Username fill Automatically 
         */
        public frmForgetPassword(string username)
        {
            InitializeComponent();
            txtUserName.Text = username;   // auto-fill
            txtUserName.ReadOnly = true;   // make uneditable
        }

        private void frmForgetPassword_Load(object sender, EventArgs e)
        {

        }
       
        private void btnResetPassword_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtNewPassword.Text.Trim()))
                {
                    txtNewPassword.Focus();
                    clsCommon.IsRequired("Password is Required");
                    return;
                }
                if (string.IsNullOrEmpty(txtRePassword.Text.Trim()))
                {
                    txtNewPassword.Focus();
                    clsCommon.IsRequired("Re-Password is Required");
                    return;
                }
                if (txtNewPassword.Text.Trim() != txtRePassword.Text.Trim())
                {
                    clsCommon.ShowErrorMessage("Passwords do not match");
                    txtRePassword.Focus();
                    return;
                }

                /*Change Password Logic  */
                clsUserLoginBAL obj = new clsUserLoginBAL();
                obj.SP_STATUS = "ChangePassword";
                obj.User_Name = txtUserName.Text.Trim();
                obj.User_Password = EncryptString.Encrypt(txtNewPassword.Text.Trim());
                DataTable dtGettLogin = obj.GetDataTable(obj);

                frmLogin f1 = new frmLogin();
                f1.ShowDialog();
                this.Close();
            }
            catch (Exception ex)
            {
                clsCommon.ShowErrorMessage("Error" + ex.Message);
            }
        }
    }
}
