﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;


namespace POS_Zota
{
    public static class clsCommon
    {
        public static void ShowErrorMessage(string Msg)
        {
            MessageBox.Show(Msg, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        public static void IsRequired(string msg)
        {
            MessageBox.Show(msg, "Required", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }


    }
}
