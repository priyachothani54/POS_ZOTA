﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Model;
using DAL;


namespace BAL
{
    public class clsUserLoginBAL : clsUserModel
    {
        SqlParameter[] GetParameter(clsUserModel obj)
        {
            SqlParameter[] Param = new SqlParameter[3];
            Param[0] = clsGeneric.GetParameter("@status", DbType.String, obj.SP_STATUS);
            Param[1] = clsGeneric.GetParameter("@Username", DbType.String, obj.User_Name);
            Param[2] = clsGeneric.GetParameter("@Password", DbType.String, obj.User_Password);
            return Param;
        }

        public DataTable GetDataTable(clsUserModel obj)
        {
            return clsUserDAL.GetDataTable(GetParameter(obj));
        }

    }
}
