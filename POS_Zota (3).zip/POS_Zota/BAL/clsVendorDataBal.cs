﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using Model;
using System.Data;
using System.Data.SqlClient;

namespace BAL
{
    public class clsVendorDataBal : clsVendorDataModel
    {
        SqlParameter[] GetParameter(clsVendorDataModel obj)
        {
            SqlParameter[] Param = new SqlParameter[1];
            Param[0] = clsGeneric.GetParameter("@status", DbType.String, obj.SP_Status);
         
            return Param;
        }

        public DataTable GetDataTable(clsVendorDataModel obj)
        {
            return clsVendorDataDal.GetDataTable(GetParameter(obj));
        }

    }
}
