﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using Model;
using System.Data;
using System.Data.SqlClient;

namespace BAL
{
    public class clsPINumberBAL : clsPINumberModel
    {

        SqlParameter[] GetParameter(clsPINumberModel obj)
        {
            SqlParameter[] Param = new SqlParameter[2];
            Param[0] = clsGeneric.GetParameter("@status", DbType.String, obj.SP_STATUS);
            Param[1] = clsGeneric.GetParameter("@PurchaseInvoiceNumber", DbType.String, obj.PurchaseInvoice_No);
            return Param;
        }

        public DataTable GetDataTable(clsPINumberModel obj)
        {
            return clsPINumberDAL.GetDataTable(GetParameter(obj));
        }


        public object GetSingleValue(clsPINumberModel obj)
        {
            return clsPINumberDAL.GetSingleValue(GetParameter(obj));
        }

        
    }
}
